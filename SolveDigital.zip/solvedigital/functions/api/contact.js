const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {"content-type":"application/json;charset=UTF-8","cache-control":"no-store"}
});

const clean = (value, max) => String(value ?? "").trim().slice(0, max);

async function verifyTurnstile(token, secret, ip) {
  if (!secret) return true; // Enables testing before Turnstile credentials are added.
  if (!token) return false;
  const form = new FormData();
  form.append("secret", secret);
  form.append("response", token);
  if (ip) form.append("remoteip", ip);
  const result = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST", body: form
  });
  const data = await result.json();
  return data.success === true;
}

async function sendEmail(env, subject, html, replyTo) {
  if (!env.RESEND_API_KEY) return {sent:false, reason:"RESEND_API_KEY not configured"};
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.RESEND_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: env.EMAIL_FROM || "SolveDigital Website <onboarding@resend.dev>",
      to: [env.CONTACT_EMAIL || "solvedigital.co@gmail.com"],
      reply_to: replyTo,
      subject,
      html
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Email delivery failed");
  return {sent:true, id:data.id};
}

export async function onRequestPost({request, env}) {
  if (request.method !== "POST") return json({error:"Method not allowed"}, 405);

  const body = await request.json().catch(() => null);
  if (!body) return json({error:"Invalid request."}, 400);

  // Honeypot: bots commonly fill hidden fields.
  if (clean(body.website, 20)) return json({message:"Thanks. Your enquiry has been received."});

  const name = clean(body.name, 80);
  const email = clean(body.email, 120);
  const company = clean(body.company, 100);
  const service = clean(body.service, 100);
  const message = clean(body.message, 4000);

  if (!name || !email || !service || !message) return json({error:"Please complete all required fields."}, 400);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({error:"Please enter a valid email address."}, 400);

  const ip = request.headers.get("CF-Connecting-IP") || "";
  const human = await verifyTurnstile(body.turnstileToken, env.TURNSTILE_SECRET, ip);
  if (!human) return json({error:"Human verification failed. Please try again."}, 403);

  const createdAt = new Date().toISOString();

  if (env.SOLVEDIGITAL_DB) {
    await env.SOLVEDIGITAL_DB.prepare(
      `INSERT INTO contact_submissions (name,email,company,service,message,created_at)
       VALUES (?,?,?,?,?,?)`
    ).bind(name,email,company,service,message,createdAt).run();
  }

  const safe = x => x.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const emailHtml = `
    <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto">
      <h2>New SolveDigital project enquiry</h2>
      <p><strong>Name:</strong> ${safe(name)}</p>
      <p><strong>Email:</strong> ${safe(email)}</p>
      <p><strong>Company:</strong> ${safe(company || "Not provided")}</p>
      <p><strong>Service:</strong> ${safe(service)}</p>
      <hr><p style="white-space:pre-wrap">${safe(message)}</p>
      <hr><small>Submitted ${safe(createdAt)}</small>
    </div>`;

  try {
    await sendEmail(env, `New SolveDigital enquiry — ${service}`, emailHtml, email);
  } catch (error) {
    // The submission is already persisted in D1; do not pretend email delivery succeeded.
    return json({message:"Your enquiry was saved successfully, but email delivery is temporarily unavailable. We will retrieve the saved enquiry."}, 202);
  }

  return json({message:"Thanks. Your enquiry has been received and sent to SolveDigital."});
}