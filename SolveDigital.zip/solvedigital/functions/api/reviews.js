const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {"content-type":"application/json;charset=UTF-8","cache-control":"no-store"}
});
const clean = (value, max) => String(value ?? "").trim().slice(0, max);

async function verifyTurnstile(token, secret, ip) {
  if (!secret) return true;
  if (!token) return false;
  const form = new FormData();
  form.append("secret", secret);
  form.append("response", token);
  if (ip) form.append("remoteip", ip);
  const result = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {method:"POST",body:form});
  const data = await result.json();
  return data.success === true;
}

async function sendEmail(env, subject, html, replyTo) {
  if (!env.RESEND_API_KEY) return;
  const response = await fetch("https://api.resend.com/emails", {
    method:"POST",
    headers:{"Authorization":`Bearer ${env.RESEND_API_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({
      from: env.EMAIL_FROM || "SolveDigital Website <onboarding@resend.dev>",
      to:[env.CONTACT_EMAIL || "solvedigital.co@gmail.com"],
      reply_to:replyTo,
      subject, html
    })
  });
  if (!response.ok) throw new Error("Email delivery failed");
}

export async function onRequestGet({env}) {
  if (!env.SOLVEDIGITAL_DB) return json({reviews:[]});
  const {results} = await env.SOLVEDIGITAL_DB.prepare(
    `SELECT name,rating,review,created_at FROM reviews WHERE status='approved' ORDER BY created_at DESC LIMIT 20`
  ).all();
  return json({reviews:results || []});
}

export async function onRequestPost({request,env}) {
  const body = await request.json().catch(() => null);
  if (!body) return json({error:"Invalid request."},400);
  if (clean(body.website,20)) return json({message:"Thank you. Your review has been submitted."});

  const name = clean(body.name,80);
  const email = clean(body.email,120);
  const review = clean(body.review,1200);
  const rating = Number(body.rating);

  if (!name || !email || !review || !Number.isInteger(rating) || rating < 1 || rating > 5)
    return json({error:"Please complete the review form correctly."},400);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return json({error:"Please enter a valid email address."},400);

  const ip = request.headers.get("CF-Connecting-IP") || "";
  if (!(await verifyTurnstile(body.turnstileToken, env.TURNSTILE_SECRET, ip)))
    return json({error:"Human verification failed. Please try again."},403);

  const createdAt = new Date().toISOString();
  if (env.SOLVEDIGITAL_DB) {
    await env.SOLVEDIGITAL_DB.prepare(
      `INSERT INTO reviews (name,email,rating,review,status,created_at) VALUES (?,?,?,?,?,?)`
    ).bind(name,email,rating,review,"pending",createdAt).run();
  } else {
    return json({message:"The review form is ready, but persistent review storage has not been connected yet."},503);
  }

  const safe = x => x.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  try {
    await sendEmail(env, `New SolveDigital review — ${rating}/5`, `
      <div style="font-family:Arial,sans-serif;max-width:680px;margin:auto">
        <h2>New client review awaiting approval</h2>
        <p><strong>Name:</strong> ${safe(name)}</p>
        <p><strong>Email:</strong> ${safe(email)}</p>
        <p><strong>Rating:</strong> ${rating}/5</p>
        <blockquote style="white-space:pre-wrap">${safe(review)}</blockquote>
        <p>Approve this review in your D1 database by changing status from <code>pending</code> to <code>approved</code>.</p>
      </div>`, email);
  } catch (_) {}

  return json({message:"Thank you. Your review has been submitted for approval."});
}