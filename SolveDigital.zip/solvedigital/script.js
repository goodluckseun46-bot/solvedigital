(() => {
  "use strict";

  const CONTACT_API = "/api/contact";
  const REVIEW_API = "/api/reviews";
  const TURNSTILE_SITEKEY = "PASTE_YOUR_TURNSTILE_SITE_KEY_HERE";

  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => [...p.querySelectorAll(s)];

  $("#year").textContent = new Date().getFullYear();

  const navToggle = $(".nav-toggle");
  const nav = $(".nav");
  navToggle?.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(open));
  });
  $$(".nav a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: .12 });
  $$(".reveal").forEach(el => revealObserver.observe(el));

  const countEl = $("[data-count]");
  if (countEl) {
    const countObserver = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting) return;
      let n = 0;
      const target = Number(countEl.dataset.count);
      const timer = setInterval(() => {
        n += Math.ceil(target / 35);
        if (n >= target) { n = target; clearInterval(timer); }
        countEl.textContent = `${n}+`;
      }, 35);
      countObserver.disconnect();
    }, { threshold: .6 });
    countObserver.observe(countEl);
  }

  function mountTurnstile(container, callback) {
    if (!container || TURNSTILE_SITEKEY.includes("PASTE_")) return;
    const render = () => {
      if (window.turnstile && !container.dataset.rendered) {
        window.turnstile.render(container, {
          sitekey: TURNSTILE_SITEKEY,
          theme: "dark",
          callback,
          "expired-callback": () => { container.dataset.token = ""; },
          "error-callback": () => { container.dataset.token = ""; }
        });
        container.dataset.rendered = "1";
      }
    };
    if (window.turnstile) render(); else window.addEventListener("load", render, { once: true });
  }

  const contactTurnstile = $("[data-turnstile-container]");
  const reviewTurnstile = $("[data-review-turnstile]");
  mountTurnstile(contactTurnstile, token => contactTurnstile.dataset.token = token);
  mountTurnstile(reviewTurnstile, token => reviewTurnstile.dataset.token = token);

  async function postForm(form, endpoint, turnstileContainer, successMessage) {
    const status = $(".form-status", form);
    const button = $(".submit-button", form);
    status.className = "form-status";
    status.textContent = "";
    button.disabled = true;
    const old = button.innerHTML;
    button.innerHTML = "<span>Sending…</span><span>↗</span>";

    const data = Object.fromEntries(new FormData(form).entries());
    data.turnstileToken = turnstileContainer?.dataset.token || "";

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(data)
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Something went wrong. Please try again.");
      status.className = "form-status success";
      status.textContent = result.message || successMessage;
      form.reset();
      if (turnstileContainer && window.turnstile) {
        turnstileContainer.dataset.token = "";
        const widgetId = turnstileContainer.dataset.widgetId;
        if (widgetId) window.turnstile.reset(widgetId);
      }
    } catch (error) {
      status.className = "form-status error";
      status.textContent = error.message;
    } finally {
      button.disabled = false;
      button.innerHTML = old;
    }
  }

  $("#contactForm")?.addEventListener("submit", e => {
    e.preventDefault();
    postForm(e.currentTarget, CONTACT_API, contactTurnstile, "Thanks. Your enquiry has been received.");
  });

  const modal = $("#reviewModal");
  const openReview = () => {
    modal.setAttribute("aria-hidden", "false");
    setTimeout(() => $("input", $("#reviewForm"))?.focus(), 50);
  };
  const closeReview = () => modal.setAttribute("aria-hidden", "true");
  $$("[data-open-review]").forEach(b => b.addEventListener("click", openReview));
  $$("[data-close-review]").forEach(b => b.addEventListener("click", closeReview));
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeReview(); });

  $("#reviewForm")?.addEventListener("submit", e => {
    e.preventDefault();
    postForm(e.currentTarget, REVIEW_API, reviewTurnstile, "Thank you. Your review has been submitted for approval.");
  });

  const initialReviews = [
    {name:"Goodluck Seun", rating:5, review:"I was looking for a professional, functional, and visually stunning website, and this team delivered exactly that. Communication was seamless and the final website was perfect and easy to navigate."},
    {name:"Lily Ariana", rating:5, review:"They helped completely transform our Operations & Management by improving process efficiency, workflow documentation and project execution. Our daily workflows are smoother and projects are delivered more effectively."},
    {name:"Kathy Cobb", rating:5, review:"They helped us build a stronger online presence and implemented digital marketing strategies that successfully boosted our sales. The team was talented, responsive and dedicated."},
    {name:"Josh Lucky", rating:5, review:"They elevated our brand, transformed our visual identity and created stunning marketing materials. Professional, creative and attentive to every detail."}
  ];

  function stars(n) { return "★".repeat(n) + "☆".repeat(5 - n); }
  function initials(name) { return name.split(/\s+/).slice(0,2).map(x => x[0]).join("").toUpperCase(); }

  function renderReviews(reviews) {
    const list = $("#reviewList");
    list.innerHTML = reviews.slice(0, 4).map(r => `
      <article class="mini-review">
        <div class="stars">${stars(Number(r.rating) || 5)}</div>
        <p>“${escapeHtml(r.review)}”</p>
        <strong>${escapeHtml(r.name)}</strong>
      </article>
    `).join("");
  }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  }
  renderReviews(initialReviews);

  fetch(REVIEW_API)
    .then(r => r.ok ? r.json() : null)
    .then(data => {
      if (data?.reviews?.length) renderReviews([...initialReviews, ...data.reviews]);
    })
    .catch(() => { /* Static testimonials remain available if API is unavailable. */ });
})();