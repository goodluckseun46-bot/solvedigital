CREATE TABLE IF NOT EXISTS contact_submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT,
  service TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reviews_status_created
ON reviews(status, created_at DESC);

INSERT INTO reviews (name,email,rating,review,status,created_at)
SELECT 'Scarlett Hayes','',5,'Working with this freelance company was a game-changer for my Business Growth. They delivered perfect results with absolute professionalism. I couldn''t be happier with the outcome!','approved',datetime('now')
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE name='Scarlett Hayes');

INSERT INTO reviews (name,email,rating,review,status,created_at)
SELECT 'Goodluck Seun','goodluckseun46@gmail.com',5,'I was looking for a professional, functional, and visually stunning website, and this team delivered exactly that. Communication was seamless and the final website was perfect and easy to navigate.','approved',datetime('now')
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE name='Goodluck Seun');

INSERT INTO reviews (name,email,rating,review,status,created_at)
SELECT 'Lily Ariana','',5,'They helped completely transform our Operations & Management by improving process efficiency, workflow documentation and project execution. Our daily workflows are smoother and projects are delivered more effectively.','approved',datetime('now')
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE name='Lily Ariana');

INSERT INTO reviews (name,email,rating,review,status,created_at)
SELECT 'Kathy Cobb','',5,'They helped us build a stronger online presence and implemented digital marketing strategies that successfully boosted our sales. The team was talented, responsive and dedicated.','approved',datetime('now')
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE name='Kathy Cobb');

INSERT INTO reviews (name,email,rating,review,status,created_at)
SELECT 'Josh Lucky','',5,'They elevated our brand, transformed our visual identity and created stunning marketing materials. Professional, creative and attentive to every detail.','approved',datetime('now')
WHERE NOT EXISTS (SELECT 1 FROM reviews WHERE name='Josh Lucky');
