# SolveDigital

Professional SolveDigital website built for Cloudflare Pages + Pages Functions + D1.

## Project structure

```text
solvedigital/
├── index.html
├── style.css
├── script.js
├── schema.sql
├── wrangler.toml
├── _headers
└── functions/
    └── api/
        ├── contact.js
        └── reviews.js
```

Cloudflare Pages Functions map files under `/functions` to routes, so:
- `functions/api/contact.js` → `POST /api/contact`
- `functions/api/reviews.js` → `GET/POST /api/reviews`

## 1. GitHub

Create a repository and upload all files/folders exactly as shown.

## 2. Cloudflare

Create a Cloudflare Workers/Pages project connected to the GitHub repository.

The static frontend needs no build command. Publish the repository root.

Cloudflare Pages Functions require the `functions` folder to be at the project root.

## 3. D1 review/contact storage

Create a D1 database called `solvedigital`.

Run `schema.sql` against it.

Then bind it to the project as:

```text
SOLVEDIGITAL_DB
```

This stores contact enquiries and reviews.

## 4. Email delivery

The serverless contact endpoint uses the Resend REST API.

Add these Cloudflare environment variables/secrets:

```text
RESEND_API_KEY=your_resend_api_key
CONTACT_EMAIL=solvedigital.co@gmail.com
EMAIL_FROM=SolveDigital Website <your_verified_sender_domain@example.com>
```

For real production email, verify a sending domain in Resend and use that domain in `EMAIL_FROM`.

Until you configure Resend, the contact form will still save enquiries to D1, but it cannot honestly claim an email was delivered.

## 5. Turnstile

Create a Cloudflare Turnstile widget and put its public site key in:

```js
const TURNSTILE_SITEKEY = "YOUR_SITE_KEY";
```

Then add this server-side secret in Cloudflare:

```text
TURNSTILE_SECRET=your_turnstile_secret
```

The API validates Turnstile server-side before accepting submissions.

For initial testing, the backend permits submissions when the secret is not configured. Configure Turnstile before public launch.

## 6. Approving reviews

New reviews are stored as `pending`.

After checking a review, change:

```sql
UPDATE reviews SET status='approved' WHERE id=YOUR_REVIEW_ID;
```

Approved reviews are returned by `GET /api/reviews`.

## 7. Contact routing

All contact enquiries are:
1. validated server-side,
2. optionally checked by Turnstile,
3. saved to D1,
4. sent to `CONTACT_EMAIL` through Resend.

If Resend temporarily fails after the D1 write, the user receives a message explaining that the enquiry was saved rather than a fake "email sent" success.

## Important

The website uses an original CSS-generated visual system rather than copying another company's assets. Replace or add your own licensed images/videos later if desired.
